const execution = (firstNumber, secondNumber, yourAns)=>{
    const result = firstNumber * secondNumber;
    return result == yourAns;
}
module.exports = execution;