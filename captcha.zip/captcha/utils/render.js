const ejs = require('ejs');
const fs = require('fs');
const random = require('./random');
const path = require('path');

module.exports = function(firstNumber=0, secondNumber=0,yourAns=0, result=undefined){
    const parentFolder = path.normalize(__dirname+"/..");
    const ejsPath =path.join(parentFolder,'/views/index.ejs');
    var htmlContent = fs.readFileSync(ejsPath, 'utf8');
    var resultHtml;
    if(firstNumber || secondNumber){
     renderHtml = ejs.render(htmlContent, {filename: 'index.ejs', firstnumber: firstNumber, secondnumber: secondNumber,yourAns:yourAns, result : result});
    }
    else{
     renderHtml = ejs.render(htmlContent, {filename: 'index.ejs', firstnumber: random(), secondnumber: random(),yourAns:'', result : result});
    }
    return renderHtml;
}