module.exports = function(){
    const randomNumber = Math.floor(Math.random() * 9) + 1
    return randomNumber;
}