const http = require('http');
const chalk = require('chalk');
const render = require('./utils/render');
const execution = require('./utils/execution');
const queryString = require('querystring');
const myName = "AmitSrivastava";

const server = http.createServer((request, response)=>{
    const url = request.url;
    const method = request.method;
    console.log('******URL is ', url);
    let urlExpression =url;
    if(!url.includes(myName)){
        urlExpression = `${myName}${url}`
    }
    
    
    if(url.toLowerCase()==='/mathgame'){
        response.writeHead(301, {
            Location: urlExpression
          }).end();
    }
    else if(url === urlExpression){
        let data = '';
        request.on('data', chunk=>{
            data +=chunk;
        });
        request.on('end', ()=>{
            //console.log('request end ', data);
            const body = queryString.parse(data);
            console.log('Body is ', body);
            if(body['bt']==='check-answer'){
                const firstNumber = body['first-number'];
                const secondNumber = body['second-number'];
                const yourAns = body['yourans'];
                const result = execution(firstNumber,secondNumber, yourAns);
                response.write(render(firstNumber, secondNumber,yourAns, result));
                response.end();

            }
            else{
                response.write(render());
                response.end();
            }
            // if(buttonClicked && buttonClicked==='check-answer'){
            //     execution()
            // }
        });
       
       
    } 
    // else if(url === `/${myName}/check` && method ==='POST'){
    //     console.log('Body is ',request.body);
    // }
    else{
        response.write('Invalid URL');
        response.end();
    }
    
});
server.listen(process.env.PORT || 53701, (err)=>{
    if(err){
        console.log(chalk.red.bold('Server Crash .... '), err);
    }
    else{
        console.log(chalk.green.bold('Server Up and Running at '+server.address().port));
    }
})